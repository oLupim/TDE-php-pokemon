<form action="{{ url('pokemon'.$pokemon->id) }}" method="POST">
    @csrf
    @method('PUT')
    <input type="text" name="name" placeholder="Nome" value="{{ $pokemon->nome }}">
    <input type="text" name="name" placeholder="Tipo" value="{{ $pokemon->tipo }}">
    <input type="number" name="number" placeholder="Pontos de Poder" value="{{ $pokemon->pontos_de_poder }}">
    <button type="submit">Registrar Pokemon</button>
</form>